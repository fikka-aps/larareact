<!-- resources/views/emails/verify.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Email Verification</title>
</head>
<body>
    <p>Please click the following link to verify your email:</p>
    <a href="<?php echo e($verificationUrl); ?>">Verify Email</a>
</body>
</html>
<?php /**PATH C:\laragon\www\larareact\resources\views/emails/verify.blade.php ENDPATH**/ ?>